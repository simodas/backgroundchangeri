const cart = JSON.parse(localStorage.getItem('cart')) || [];
const products = JSON.parse(localStorage.getItem('products')) || [];

function updateCartUI() {
  document.getElementById('cart-count').textContent = cart.length;
}

function showCart() {
  document.getElementById('cart').scrollIntoView({ behavior: 'smooth' });
  displayCart();
}

function registerUser() {
  const email = document.getElementById('regEmail').value;
  const pass = document.getElementById('regPass').value;
  if (email && pass) {
    localStorage.setItem('user_' + email, pass);
    alert('تم التسجيل بنجاح!');
  }
}

function loginUser() {
  const email = document.getElementById('loginEmail').value;
  const pass = document.getElementById('loginPass').value;
  const savedPass = localStorage.getItem('user_' + email);
  if (savedPass && savedPass === pass) {
    document.getElementById('loginMessage').textContent = 'تم تسجيل الدخول بنجاح!';
    document.getElementById('add-product').classList.remove('hidden');
  } else {
    document.getElementById('loginMessage').textContent = 'بيانات الدخول غير صحيحة!';
  }
}

function addProduct() {
  const name = document.getElementById('productName').value;
  const description = document.getElementById('productDescription').value;
  const price = document.getElementById('productPrice').value;
  const image = document.getElementById('productImage').value;

  if (name && description && price && image) {
    const product = { name, description, price, image };
    products.push(product);
    localStorage.setItem('products', JSON.stringify(products));
    displayProducts();
  }
}

function displayProducts() {
  const productContainer = document.getElementById('products');
  productContainer.innerHTML = '';
  products.forEach((product, index) => {
    const productDiv = document.createElement('div');
    productDiv.innerHTML = `
      <img src="${product.image}" alt="${product.name}" style="max-width: 100%;">
      <h2>${product.name}</h2>
      <p>${product.description}</p>
      <p>${product.price} ريال</p>
      <button onclick="addToCart('${product.name}', ${product.price})">أضف إلى السلة</button>
    `;
    productContainer.appendChild(productDiv);
  });
}

function addToCart(name, price) {
  cart.push({ name, price });
  localStorage.setItem('cart', JSON.stringify(cart));
  updateCartUI();
  alert('تمت إضافة المنتج إلى السلة!');
}

function displayCart() {
  const cartContainer = document.getElementById('cart-items');
  cartContainer.innerHTML = '';
  cart.forEach((item, index) => {
    const itemDiv = document.createElement('div');
    itemDiv.innerHTML = `
      <h3>${item.name}</h3>
      <p>${item.price} ريال</p>
      <button onclick="removeFromCart(${index})">حذف</button>
    `;
    cartContainer.appendChild(itemDiv);
  });
}

function removeFromCart(index) {
  cart.splice(index, 1);
  localStorage.setItem('cart', JSON.stringify(cart));
  updateCartUI();
  displayCart();
}

displayProducts();
updateCartUI();
